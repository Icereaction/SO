Para a compila��o do programa, o utilizador necessita de executar o comando
make dentro da pasta que cont�m o projeto e abrir duas janelas de linha de comandos.
Ap�s disso, existe uma s�rie de passos a executar, sendo eles:
	1. Na primeira janela, escrever ./monitor
	2. Na segunda janela, escrever ./simulador sim.conf <tempo de simula��o> 
		<tempo de simula��o> = tempo que deseja para a simula��o. Ex: 8
	3. Na janela monitor, escrever 1. Isto come�a a simula��o.
A simula��o ir� correr at� acabar o tempo introduzido.