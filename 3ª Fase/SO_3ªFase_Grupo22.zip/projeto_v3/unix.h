#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define UNIXSTR_PATH "/tmp/s.unixstr_2063211"
#define UNIXDG_PATH  "/tmp/s.unixdgx_2063211"
#define UNIXDG_TMP   "/tmp/dgXXXXXXX_2063211"
